from flask import Flask,render_template,request 
import requests

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/tests")
def tests():
    return "Testa lapa"

@app.route("/bilde")
def bilde():
    return render_template("bilde.html")

@app.route("/fakti")
def fakti():
    return render_template("fakti.html")

@app.route("/universitates",methods=['GET','POST'])
def universitates():
    kluda = ""
    dati = []
    if "ieladet" in request.form:
        if request.form["vertiba"] == "":
            kluda = "Nav norādīta valsts!"
        else:
            if request.form['veids'] == "1":
                izsaukums = requests.get(f"http://universities.hipolabs.com/search?country={request.form["vertiba"]}")
                dati = izsaukums.json()
                if len(dati) == 0:
                    kluda="Datu nav!"
            elif request.form['veids'] == "2":
                izsaukums = requests.get(f"http://universities.hipolabs.com/search?name={request.form["vertiba"]}")
                dati = izsaukums.json()
                if len(dati) == 0:
                    kluda="Datu nav!"
            else:
                kluda="Nepareizs veids!"
                
    return render_template("universitates.html",kluda=kluda,dati=dati)

app.run(debug=True,host="0.0.0.0", port=80)
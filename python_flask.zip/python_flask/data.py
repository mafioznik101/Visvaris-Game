import sqlite3
import time
import random
import uuid
import bcrypt
 
# Declaring our password
password = b'ailavkam'
parole2 = b'ailavkam'
# Adding the salt to password
salt = bcrypt.gensalt()
# Hashing the password
hashed = bcrypt.hashpw(password, salt)
hashed2 = bcrypt.hashpw(parole2, salt)
if hashed == hashed2:
    print("Veiksmīgi")
else:
    print("pizda boss")
# printing the salt
print("Salt :")
print(salt)
 
# printing the hashed
print("Hashed")
print(hashed)
con = sqlite3.connect("lietotaji.sqlite", timeout=5)
def dict_factory(cursor, row):
    fields = [column[0] for column in cursor.description]
    return {key: value for key, value in zip(fields, row)}

# con.row_factory = dict_factory
# cur = con.cursor()
# vaicajums = cur.execute(f"SELECT * FROM lietotaji")
# con.isolation_level = None
# rezultats = vaicajums.fetchall()
#iduuid = uuid.uuid4()
#print(sha256)
class lietotaja_izveide:
    uiid = uuid.uuid4()  # Class attribute

    def __init__(self, vards, parole, email):
        self.vards = vards  # atribūts
        self.parole = parole  # atribūts
        self.email = email  # atribūts

# Creating an object of the Dog class
dog1 = lietotaja_izveide("martins2006","habibi", "martinsvagins@gmaill.com")

print(dog1.vards) 
print(dog1.parole) 
print(dog1.email) 
print(dog1.uiid)

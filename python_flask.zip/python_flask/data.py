import sqlite3
import uuid
import bcrypt
import base64
 
import bcrypt

# Step 1: Hash the password (store this in the DB)
password = b"habibi"
hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())  # ✅ Hash with salt

print("Stored Hash:", hashed_password)  # Example: b'$2b$12$H5D45j...5kNweI1'

# Step 2: Verify the password later (retrieve hash from DB)
input_password = b"ailavkam"
hashed2 = bytes("$2b$12$9JzVxw207LUNZ9/rlLavduylB4USGjXGXZKYiTLFew0TcBVwvNRrq", 'utf-8')

if bcrypt.checkpw(input_password, hashed2):  # ✅ Correct way to verify
    print("Pareizi ")
else:
    print("pizda boss")

con = sqlite3.connect("lietotaji.sqlite", timeout=5)
cur = con.cursor()
con.isolation_level = None
#klase, kur izveidosies lietotājs
class Lietotajaizveide:
    vards = None
    parole = None
    uuid = None
    email = None
    sifrsemail = None
    def __init__(self, vards, parole, email):
        self.uuid = str(uuid.uuid4()) #identifikators
        self.vards = vards
        self.parole = self.sifresana(parole)
        self.email = self.base64_sifresana(email)
        
    def base64_sifresana(self, email):
        sifrs1 = email.encode("ascii")
        base64_sifrs = base64.b64encode(sifrs1)
        return base64_sifrs.decode("ascii")
    
    def base64_atsifresana(self):
        sifrs2 = (self.email).encode("ascii")
        base64_atsifrs = base64.b64decode(sifrs2)
        return base64_atsifrs.decode("ascii")
    
    def sifresana(self, parole):
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(parole.encode(), salt)
    
    def saglabat_db(self):
        try:
            cur.execute("INSERT INTO lietotaju_info (vards, parole, email, uuid) VALUES (?, ?, ?, ?)",(self.vards, self.parole, self.email, self.uuid),)
            con.commit()
            print(f"Lietotājs {self.vards} pievienots")
        except sqlite3.IntegrityError as kluda:
            if "UNIQUE constraint failed" in str(kluda):
                print("Lietotājvārds ir aizņemts")
                return False
            else:
                print("Datubāzes kļūda")
        finally:
            con.close()
                
    def parbaudit_db(self, parole_ievade):
        cur.execute("SELECT parole FROM lietotaju_info WHERE vards = ?",(self.vards,))
        db_parole = cur.fetchone()
        if db_parole is None:
            print("Lietotājvārds nav atrasts!")
            return False
        db_parole = db_parole[0]
        con.commit()
        print(db_parole)
        print("Self parole ievade:", parole_ievade)
        print("DB parole:", db_parole)
        if bcrypt.checkpw(parole_ievade.encode(), db_parole):
            return True
        else:
            return False
        
lietotajs = Lietotajaizveide("bigdickmarkuss", "moneyswaghoes", "markussprusis@bvsk.lv")
# if not lietotajs.saglabat_db():
#     print("bruh")
lietotajs.parbaudit_db("moneyswaghoes")
print("Vārds:", lietotajs.vards)
print("Parole (šifrēta):", lietotajs.parole)
print("E-pasts:", lietotajs.email)
print("UUID:", lietotajs.uuid)
print(lietotajs.base64_atsifresana()) #atsifretais email
class Publikacija:
    vards = None
    tituls = None
    posta_teksts = None
    bildes_saite = None
    user_id = None
    post_id = None
    def __init__(self, vards, tituls, posta_teksts, bildes_saite, user_id, post_id):
        self.vards = vards
        self.tituls = tituls
        self.posta_teksts = posta_teksts
        self.bildes_saite = bildes_saite
        self.user_id = user_id
        self.post_id = post_id
    def pievienot_post(self):
        cur.execute("INSERT INTO posti (tituls, posta_teksts, bildes_saite, user_id, post_id VALUES (?, ?, ?, ?, ?) )")
        con.commit()
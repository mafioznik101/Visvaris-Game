import requests

ievade = input("Ievadi valsti")

if ievade != "":
    izsaukums = requests.get(f"http://universities.hipolabs.com/search?country={ievade}")
    if izsaukums.status_code == 200:
        atbilde = izsaukums.json()
        for universitate in atbilde:
            print(f"Nosaukums: {universitate['name']}, domēni: {",".join(universitate['domains'])}, tīmekļa adreses: {",".join(universitate['web_pages'])} ")
    else:
        print("Neatgrieza neko")
else:
    print("Ievadi valsti!")
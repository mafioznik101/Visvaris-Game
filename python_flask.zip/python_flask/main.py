from flask import Flask,render_template, request

app = Flask(__name__)

#TEMPLATES_AUTO_RELOAD = True
@app.route("/izkartosanas")
def izkartojums():
   return render_template('izkartojums.html')


@app.route("/parmums")
def parmums():
   return render_template('parmums.html')

@app.route("/")
def index():
   return render_template('index.html')

@app.route("/login")
def login():
   return render_template('login.html')

@app.route('/posts')
def renderThisPath():
  res = render_template('posts.html', 
                       some='variables',
                       you='want',
                       toPass=['to','your','template'])
  return res
# if __name__ == '__main__':  
#    app.run(debug = True)
app.run(debug=True,host="0.0.0.0", port=80)